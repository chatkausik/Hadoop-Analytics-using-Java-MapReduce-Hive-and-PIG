package Subpatent_Count;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducePatentClass extends Reducer<IntWritable, IntWritable, IntWritable, LongWritable>{
	public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{
		long x = 0;
		//How {1,1,1,1}
		for(IntWritable val: values) {
			x = x + val.get();
		}
		
	context.write(key,  new LongWritable(x));
	}

}