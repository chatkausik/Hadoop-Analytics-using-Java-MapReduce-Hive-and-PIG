package Subpatent_Count;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapPatentClass extends Mapper<LongWritable, Text, IntWritable, IntWritable>{
	public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
		
		// 1 1 1.11
		// 1 2.23
		// 2 3.99
		// 2 4.56
		String s1 = values.toString();
		String arr[] = s1.split(" ");
        Integer patent = Integer.parseInt(arr[0]);
		// 1
		// 1
		// 2
		// 2
		
		
		IntWritable patentid = new IntWritable(patent);
		IntWritable one = new IntWritable(1);
		context.write(patentid,one);
		    
		    // 1,1
		    //1,1
		    //2,1
		    //2,1
		}
			

}