//Apply your MapReduce programming knowledge and write a MapReduce program to process a dataset with a patent records. 
//You need to calculate the number of sub-patents associated with each patent.
package Subpatent_Count;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class SubPatentCountDriver {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration conf = new Configuration();
		Job job = new Job(conf);
		job.setJarByClass(SubPatentCountDriver.class);
		job.setMapperClass(MapPatentClass.class);
        job.setNumReduceTasks(1);
        job.setReducerClass(ReducePatentClass.class);
        
        job.setOutputKeyClass(IntWritable.class); 
        job.setOutputValueClass(IntWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        FileSystem fs = FileSystem.get(conf);
        fs.delete(new Path(args[1]));
        job.waitForCompletion(true);

	}

}
