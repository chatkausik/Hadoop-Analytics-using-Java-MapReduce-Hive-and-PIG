package alphabetcount;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapAlphabetClass extends Mapper<LongWritable, Text, IntWritable, IntWritable>{
	public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
		
		// 1 How are you doing today
		
		String s1 = values.toString().toLowerCase();  //Convert from hadoop Text to Java String.
		String arr[] = s1.split(" ");   //Split the sentences to get each word.
		//System.out.println(arr);
		//[0] 3
		//[1] 3
		//[2] 3
		//[3] 5
		//[4] 5
		
		for (String  x : arr)
		{
			IntWritable word_size = new IntWritable(x.length());
			IntWritable one = new IntWritable(1);
			//System.out.println(word_size);
		    context.write(word_size,one);
		    //System.out.println(word_size + "," + one);
		    
		    // 3,1
		    //3,1
		    //3,1
		    //5,1
		    //5,1
		}
		
	}
	

}