package WeatherHotCold;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MaphotcoldClass extends Mapper<LongWritable, Text, Text, Text>{
	//static long counter = 0; 
	
	public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
		
		//counter++;
		
		String s1 = values.toString().trim();  //Convert from hadoop Text to Java String.
		String arr[] = s1.split("\\s+");   

    	    String date = arr[1];
    	    
        Double maxtemp = Double.parseDouble(arr[5]);
        Double mintemp = Double.parseDouble(arr[6]);
        System.out.println("date="+ date + "minTemp=" + mintemp + "maxTemp=" + maxtemp);
		
        String coldDay = "";
    	
      	if(mintemp < 10 ) {
    		     coldDay = "Cold Day";
      	}
     	else if (maxtemp > 40)
    		     coldDay = "Hot Day";
    	    else coldDay = "Normal Day";
    	     	            	
        context.write(new Text(date), new Text(coldDay)); 

		    
		    
		}
		
	}
	
