package ISDCallAnalysis;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.shell.PathData;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;

public class MapISDClass extends Mapper<LongWritable,Text,Text,DoubleWritable>{
	
	HashMap<Integer,String> countrymaster = new HashMap<Integer,String>() ;		
	//Array of Key, value pairs.
	//1, Argentina
	//2, USA
	//3, Australia
	//13, India
	
	protected void map(LongWritable key, Text value, Mapper<LongWritable,Text,Text,DoubleWritable>.Context context)
	   throws IOException, InterruptedException {
		//1 9876543210,0987654321,15,1
		//1 9876543210,0987654321,15,13
		String inputstring = value.toString().trim();
		String [] arr = inputstring.split(",");
		
		Integer cid = Integer.parseInt(arr[3]);
		Double cd  = Double.parseDouble(arr[2]);
		
		if (countrymaster.containsKey(cid))
		{
			if (!(countrymaster.get(cid).toUpperCase().trim().equals("INDIA")))
			{
				context.write(new Text(countrymaster.get(cid).toUpperCase().trim()), new DoubleWritable(cd));
			}
		}
		
		//Argentina,15
				
			
	}
	
	protected void setup(Mapper<LongWritable,Text,	Text,DoubleWritable>.Context context)
		throws IOException, InterruptedException {
		
		@SuppressWarnings("deprecation")
		Path[] p = 	DistributedCache.getLocalCacheFiles(context.getConfiguration());
		
		for(Path x: p)
		{
			BufferedReader br = new BufferedReader(new FileReader(x.toString()));
			String inputstr = br.readLine();
			while(inputstr != null)
			{
				countrymaster.put(Integer.parseInt(inputstr.trim().split(",")[0]), inputstr.split(",")[1].toUpperCase().trim());
			}
		}
	}

}
