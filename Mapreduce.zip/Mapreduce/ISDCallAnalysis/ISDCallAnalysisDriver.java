package ISDCallAnalysis;

import java.net.URI;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.filecache.DistributedCache;
import org.apache.hadoop.mapreduce.lib.db.DBWritable;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


@SuppressWarnings("deprecation")
public class ISDCallAnalysisDriver {

	public static void main(String[] args) throws Exception{
		Configuration conf = new Configuration();
		Job job = new Job(conf);
		job.setJarByClass(ISDCallAnalysisDriver.class);	
		
		DistributedCache.addCacheFile(new URI(args[0]), job.getConfiguration());
		
		job.setMapperClass(MapISDClass.class);
        job.setNumReduceTasks(1);
        job.setReducerClass(ReduceISDClass.class);
        
        job.setOutputKeyClass(Text.class); //word text
        job.setOutputValueClass(DBWritable.class);
        FileInputFormat.addInputPath(job, new Path(args[1]));
        FileOutputFormat.setOutputPath(job, new Path(args[2]));
        FileSystem fs = FileSystem.get(conf);
        fs.delete(new Path(args[2]));
        job.waitForCompletion(true);
        
	}

}

