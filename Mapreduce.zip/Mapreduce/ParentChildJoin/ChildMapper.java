package ParentChildJoin;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ChildMapper extends Mapper<LongWritable, Text, IntWritable, Text>{
	protected void map(LongWritable key, Text values, Mapper<LongWritable, Text, IntWritable, Text>.Context context) throws IOException, InterruptedException {
		
		// 1 1,A,1 (CID,CNAME,PID)
		
		String s1 = values.toString().trim();  //Convert from hadoop Text to Java String.
		String arr[] = s1.split(",");   //Split the sentences to get each.

		
        Integer PID = Integer.parseInt(arr[2]);
		String name = arr[1];
		context.write(new IntWritable(PID), new Text( name + "," + "CNAME"));
		    
		// 1, (A,CNAME) 
		 
		}
		
	}

