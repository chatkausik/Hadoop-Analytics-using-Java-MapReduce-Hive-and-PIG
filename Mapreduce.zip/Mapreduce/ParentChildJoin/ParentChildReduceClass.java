package ParentChildJoin;

import java.io.IOException;
import java.util.Vector;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ParentChildReduceClass extends Reducer<IntWritable, Text, Text, Text>{
	@SuppressWarnings("unchecked")
	protected void reduce(IntWritable arg0, Iterable<Text> values, Reducer<IntWritable, Text, Text, Text>.Context context) throws IOException, InterruptedException{
    
	String Pname ="";
	@SuppressWarnings("rawtypes")
	Vector v = new Vector();
	
	// 1, {ABC|PNAME, A|CNAME}
	
	for (Text x : values)
	{
		if (x.toString().split(",")[1].trim().toUpperCase().equals("PNAME"))
		{
			Pname = x.toString().trim().split(",")[0];
		}
		if (x.toString().trim().split(",")[1].toUpperCase().equals("CNAME"))
		{
			v.addElement(x.toString().trim().split(",")[0]);
		}
	}
	
	//Pname = ABC
	//v:{A}
	
	if (Pname.length() == 0)
	{
		Pname= "No Parent";
	}
	
	for (Object y: v)
	{
		context.write(new Text(Pname),  new Text(y.toString().trim()));
	}
	
	if(v.isEmpty())
	{
		context.write(new Text(Pname),  new Text("No Children"));
	}
		
	
	}

}
