package YearMaxTemp;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapmaxtempClass extends Mapper<LongWritable, Text, IntWritable, IntWritable>{
	public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
		
		// 1 1990 34
		// 2 1990 45
		// 3 1990 24
		
		String s1 = values.toString();  //Convert from hadoop Text to Java String.
		String arr[] = s1.split(" ");   
		//[0] 1990
		//[1] 34
        Integer year = Integer.parseInt(arr[0]);
        Integer temp = Integer.parseInt(arr[1]);
		
		
		IntWritable yearvar = new IntWritable(year);
		IntWritable tempvar = new IntWritable(temp);
		context.write(yearvar,tempvar);
		    
		    //1990, 34
		    //1990, 45
		    //1990, 24
		    
		}
		
	}
	
