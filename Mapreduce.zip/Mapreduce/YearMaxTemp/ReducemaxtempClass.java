package YearMaxTemp;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducemaxtempClass extends Reducer<IntWritable, IntWritable, IntWritable, IntWritable>{
	public void reduce(IntWritable key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{
		int max = 0;
		//1990, {34, 45, 24}
     
		for(IntWritable val: values) {
			if (val.get() > max)
			{
				max = val.get();
			}
		}
		
	context.write(key,  new IntWritable(max));
	}

}