package WordCount;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapClass extends Mapper<LongWritable, Text, Text, IntWritable>{
	public void map(LongWritable key, Text values, Context context) throws IOException, InterruptedException {
		
		// 1 How are you doing today
		
		String s1 = values.toString();  //Convert from hadoop Text to Java String.
		String arr[] = s1.split(" ");   //Split the sentences to get each word.
		//[0] How
		//[1] are
		//[2] you
		//[3] doing
		//[4] today
		
		for (String  x : arr)
		{
			Text word = new Text(x.toLowerCase());
			IntWritable one = new IntWritable(1);
		    context.write(word,one);
		    
		    // How,1
		    //are,1
		    //you,1
		    //doing,1
		}
		
	}
	

}
