package WordCount;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReduceClass extends Reducer<Text, IntWritable, Text, IntWritable>{
	public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException{
		int x = 0;
		//How {1,1,1,1}
		for(IntWritable val: values) {
			x = x + val.get();
		}
		
	context.write(key,  new IntWritable(x));
	}

}
