package SalesRegionwise;

//Using Hadoop Gen 1

import java.io.IOException;
import java.util.Iterator;
import java.util.StringTokenizer;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Partitioner;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

public class WithCombiner_and_Partitioner {

	public static class Map extends MapReduceBase implements
			Mapper<LongWritable, Text, Text, DoubleWritable> {

		@Override
		public void map(LongWritable key, Text value,
				OutputCollector<Text, DoubleWritable> output, Reporter reporter)
				throws IOException {
			
			//Input to Map
            //1, Mumbai, 25000
			//2, Bangalore, 20000
			//3, Kolkata, 5000
			
			String line = value.toString().trim();
			String arr[] = line.split(",");
			Double sales = Double.parseDouble(arr[1]);

			output.collect(new Text(arr[0]), new DoubleWritable(sales));
			
			//Output of Map
			//Mumbai, 25000
			//Bangalore, 20000
			//Kolkata, 5000

		}
	}

	// Output types of Mapper should be same as arguments of Partitioner
	public static class MyPartitioner implements Partitioner<Text, DoubleWritable> {

		@Override
		public int getPartition(Text key, DoubleWritable value, int numPartitions) {

			String myKey = key.toString().toLowerCase();

			if (myKey.equals("chennai")) {
				return 0;
			}
			if (myKey.equals("bangalore")) {
				return 0;
			}
			if (myKey.equals("mumbai")) {
				return 1;
			}
			if (myKey.equals("surat")) {
				return 1;
			}
			if (myKey.equals("goa")) {
				return 2;
			}
			if (myKey.equals("pune")) {
				return 2;
			} else {
				return 3;
			}
		}

		@Override
		public void configure(JobConf arg0) {

			// Gives you a new instance of JobConf if you want to change Job
			// Configurations

		}
	}

	public static class Reduce extends MapReduceBase implements
			Reducer<Text, DoubleWritable, Text, DoubleWritable> {

		@Override
		public void reduce(Text key, Iterator<DoubleWritable> values,
				OutputCollector<Text, DoubleWritable> output, Reporter reporter)
				throws IOException {

			int sum = 0;
			while (values.hasNext()) {
				sum += values.next().get();
				// sum = sum + 1;
			}

			// beer,3

			output.collect(key, new DoubleWritable(sum));
		}
	}

	public static void main(String[] args) throws Exception {

		JobConf conf = new JobConf(WithCombiner_and_Partitioner.class);
		conf.setJobName("SalesByRegion");

		// Forcing program to run 4 reducers for 4 regions South, West, North and Others.
		conf.setNumReduceTasks(4);

		conf.setMapperClass(Map.class);
		conf.setCombinerClass(Reduce.class);
		conf.setReducerClass(Reduce.class);
		conf.setPartitionerClass(MyPartitioner.class);

		conf.setOutputKeyClass(Text.class);
		conf.setOutputValueClass(DoubleWritable.class);

		conf.setInputFormat(TextInputFormat.class);
		conf.setOutputFormat(TextOutputFormat.class);

		 FileInputFormat.setInputPaths(conf, new Path(args[0]));
		 FileOutputFormat.setOutputPath(conf, new Path(args[1]));
		 
		JobClient.runJob(conf);
	}
}
